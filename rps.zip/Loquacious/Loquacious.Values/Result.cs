﻿namespace Loquacious.Values
{
    public enum Result
    {
        NoPicks = -1,
        None = 0,
        Tie = 1,
        Victory = 2
    }
}