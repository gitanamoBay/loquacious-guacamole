﻿namespace Loquacious.Values
{
    public enum GameMode
    {
        None = 0,
        PvsAi = 1,
        PvsP = 2,
        AivsAi = 3
    }
}