﻿namespace Loquacious.Values
{
    public enum Pick
    {
        None = 0,
        Rock = 1,
        Paper = 2,
        Scissors = 3
    }
}